# typed: strong
# frozen_string_literal: true

module Tapioca
  VERSION = "0.7.0"
end
