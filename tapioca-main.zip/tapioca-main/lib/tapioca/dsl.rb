# typed: true
# frozen_string_literal: true

require "tapioca"
require "tapioca/runtime/reflection"
require "tapioca/dsl/compiler"
